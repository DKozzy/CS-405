// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <exception>
#include <string>

// Custom exception class derived from std::exception
class CustomApplicationException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom application exception occurred.";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throw a standard exception to demonstrate std::exception handling
    throw std::runtime_error("Standard exception thrown from even more custom application logic.");

    return true;
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    std::cout << "Running Custom Application Logic." << std::endl;

    // Added try block to handle standard exceptions from the function call
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& exception)
    {
        std::cout << "Caught standard exception in custom application logic: "
            << exception.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    // Throw custom exception to be handled in main
    throw CustomApplicationException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    // Check for divide-by-zero before performing division
    if (den == 0)
    {
        throw std::runtime_error("Cannot divide by zero.");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    // Added try/catch block to specifically handle division exceptions
    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& exception)
    {
        std::cout << "Caught division exception: " << exception.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.

    // Added try/catch handlers around the main application logic
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomApplicationException& exception)
    {
        std::cout << "Caught custom exception in main: "
            << exception.what() << std::endl;
    }
    catch (const std::exception& exception)
    {
        std::cout << "Caught standard exception in main: "
            << exception.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Caught unknown exception in main." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu